package com.xcheko51x.navigationdrawertabsandroidx;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import com.xcheko51x.navigationdrawertabsandroidx.Tabs.TabDosFragment;
import com.xcheko51x.navigationdrawertabsandroidx.Tabs.TabUnoFragment;

public class TabsPagerAdapter extends FragmentPagerAdapter {

    int[] TITULOS_TABS = new int[] {R.string.tab_text_uno, R.string.tab_text_dos};
    Context mContext;

    public TabsPagerAdapter(Context mContext, @NonNull FragmentManager fm) {
        super(fm);
        this.mContext = mContext;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0: return new TabUnoFragment();
            case 1: return new TabDosFragment();
            default: return null;
        }
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mContext.getResources().getString(TITULOS_TABS[position]);
    }

    @Override
    public int getCount() {
        return 2;
    }
}
